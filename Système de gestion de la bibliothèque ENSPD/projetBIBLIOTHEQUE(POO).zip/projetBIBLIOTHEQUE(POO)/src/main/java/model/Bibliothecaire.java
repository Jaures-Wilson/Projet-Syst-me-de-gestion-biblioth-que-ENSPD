package model;

public class Bibliothecaire {
	private int idBibliothecaire;
    private String nomBibliothecaire;
    private String motDePasse;
    
	public int getIdBibliothecaire() {
		return idBibliothecaire;
	}
	public void setIdBibliothecaire(int idBibliothecaire) {
		this.idBibliothecaire = idBibliothecaire;
	}
	public String getNomBibliothecaire() {
		return nomBibliothecaire;
	}
	public void setNomBibliothecaire(String nomBibliothecaire) {
		this.nomBibliothecaire = nomBibliothecaire;
	}
	public String getMotDePasse() {
		return motDePasse;
	}
	public void setMotDePasse(String motDePasse) {
		this.motDePasse = motDePasse;
	}

    
}
